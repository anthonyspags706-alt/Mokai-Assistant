const { 
    Client, 
    GatewayIntentBits, 
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');
const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers
    ]
});

const app = express();
const PORT = process.env.PORT || 3000;
const DOMAIN = process.env.DOMAIN || `http://localhost:${PORT}`;

// ===== CONFIGURATION =====
const CONFIG = {
    ROBLOX_CLIENT_ID: process.env.ROBLOX_CLIENT_ID,
    ROBLOX_CLIENT_SECRET: process.env.ROBLOX_CLIENT_SECRET,
    REDIRECT_URI: `${DOMAIN}/callback`,
    GUILD_ID: process.env.GUILD_ID,
    VERIFIED_ROLE_ID: process.env.VERIFIED_ROLE_ID,
    VERIFY_CHANNEL_ID: process.env.VERIFY_CHANNEL_ID,
    
    // Group role mappings: Roblox Group Rank ID -> Discord Role ID
    GROUP_ID: process.env.ROBLOX_GROUP_ID, // Your Roblox group ID
    
    // Special rank-based roles
    RANK_ROLES: {
        // If rank >= 235, add this role
        HIGH_RANK: { minRank: 235, roleId: '1436500180869582909' },
        // If rank between 239-242, add this role
        MID_HIGH_RANK: { minRank: 239, maxRank: 242, roleId: '1436499150995849418' },
        // If rank between 246-249, add this role
        SENIOR_RANK: { minRank: 246, maxRank: 249, roleId: '1436499199528009768' },
        // If rank between 250-255, add this role
        LEADERSHIP_RANK: { minRank: 250, maxRank: 255, roleId: '1436503259186462730' }
    }
};

// Store verification sessions (in production, use a database)
const verificationSessions = new Map(); // state -> { userId, guildId, timestamp }
const verifiedUsers = new Map(); // discordId -> { robloxId, robloxUsername }

// ===== EXPRESS ROUTES =====
app.get('/', (req, res) => {
    res.send('🔗 Roblox Verification System is running!');
});

// Start verification - sends to Discord OAuth first
app.get('/start-verify', (req, res) => {
    const guildId = req.query.guild;
    
    if (!guildId) {
        return res.status(400).send('Missing guild ID');
    }

    // Generate random state for CSRF protection
    const state = crypto.randomBytes(16).toString('hex');
    
    // Store session
    verificationSessions.set(state, {
        guildId: guildId,
        timestamp: Date.now(),
        step: 'discord'
    });

    // Clean up old sessions (older than 10 minutes)
    for (const [key, value] of verificationSessions.entries()) {
        if (Date.now() - value.timestamp > 600000) {
            verificationSessions.delete(key);
        }
    }

    // Discord OAuth URL
    const discordAuthUrl = `https://discord.com/api/oauth2/authorize?` +
        `client_id=${client.user.id}` +
        `&redirect_uri=${encodeURIComponent(`${DOMAIN}/discord-callback`)}` +
        `&response_type=code` +
        `&scope=identify guilds.join` +
        `&state=${state}`;

    res.redirect(discordAuthUrl);
});

// Discord OAuth callback
app.get('/discord-callback', async (req, res) => {
    const { code, state } = req.query;

    if (!code || !state) {
        return res.status(400).send('❌ Missing code or state parameter');
    }

    // Verify state
    const session = verificationSessions.get(state);
    if (!session || session.step !== 'discord') {
        return res.status(400).send('❌ Invalid or expired session. Please try verifying again.');
    }

    try {
        // Exchange code for Discord access token
        const tokenResponse = await axios.post('https://discord.com/api/oauth2/token',
            new URLSearchParams({
                client_id: client.user.id,
                client_secret: process.env.DISCORD_CLIENT_SECRET,
                grant_type: 'authorization_code',
                code: code,
                redirect_uri: `${DOMAIN}/discord-callback`
            }), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        const accessToken = tokenResponse.data.access_token;

        // Get Discord user info
        const userResponse = await axios.get('https://discord.com/api/users/@me', {
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });

        const userId = userResponse.data.id;
        const username = userResponse.data.username;

        // Update session with Discord info
        session.userId = userId;
        session.username = username;
        session.step = 'roblox';
        verificationSessions.set(state, session);

        // Now redirect to Roblox OAuth
        const robloxAuthUrl = `https://apis.roblox.com/oauth/v1/authorize?` +
            `client_id=${CONFIG.ROBLOX_CLIENT_ID}` +
            `&redirect_uri=${encodeURIComponent(CONFIG.REDIRECT_URI)}` +
            `&scope=openid profile` +
            `&response_type=code` +
            `&state=${state}`;

        res.redirect(robloxAuthUrl);

    } catch (error) {
        console.error('Discord OAuth error:', error.response?.data || error);
        verificationSessions.delete(state);
        res.status(500).send('❌ Discord verification failed. Please try again.');
    }
});

// Roblox OAuth callback
app.get('/callback', async (req, res) => {
    const { code, state } = req.query;

    if (!code || !state) {
        return res.status(400).send('❌ Missing code or state parameter');
    }

    // Verify state
    const session = verificationSessions.get(state);
    if (!session || session.step !== 'roblox') {
        return res.status(400).send('❌ Invalid or expired session. Please try verifying again.');
    }

    verificationSessions.delete(state);

    try {
        // Exchange code for Roblox access token
        const tokenResponse = await axios.post('https://apis.roblox.com/oauth/v1/token', 
            new URLSearchParams({
                grant_type: 'authorization_code',
                code: code,
                redirect_uri: CONFIG.REDIRECT_URI
            }), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': `Basic ${Buffer.from(`${CONFIG.ROBLOX_CLIENT_ID}:${CONFIG.ROBLOX_CLIENT_SECRET}`).toString('base64')}`
                }
            }
        );

        const accessToken = tokenResponse.data.access_token;

        // Get Roblox user info
        const userInfoResponse = await axios.get('https://apis.roblox.com/oauth/v1/userinfo', {
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });

        const robloxId = userInfoResponse.data.sub;
        const robloxUsername = userInfoResponse.data.preferred_username;

        // Get user's group role
        let groupRank = null;
        let groupRoleName = null;
        if (CONFIG.GROUP_ID) {
            try {
                const groupResponse = await axios.get(
                    `https://groups.roblox.com/v1/users/${robloxId}/groups/roles`
                );
                
                const userGroup = groupResponse.data.data.find(
                    g => g.group.id.toString() === CONFIG.GROUP_ID
                );
                
                if (userGroup) {
                    groupRank = userGroup.role.rank;
                    groupRoleName = userGroup.role.name;
                }
            } catch (error) {
                console.error('Error fetching group info:', error);
            }
        }

        // Store verification
        verifiedUsers.set(session.userId, {
            robloxId: robloxId,
            robloxUsername: robloxUsername,
            groupRank: groupRank,
            groupRoleName: groupRoleName,
            verifiedAt: Date.now()
        });

        // Update Discord user
        let member;
        try {
            const guild = await client.guilds.fetch(session.guildId);
            member = await guild.members.fetch(session.userId).catch(async () => {
                // User not in server, they need to join first
                return null;
            });

            if (!member) {
                return res.send(`
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Join Server First</title>
                        <style>
                            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
                            .container { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); text-align: center; max-width: 500px; }
                            h1 { color: #667eea; margin-bottom: 20px; }
                            p { font-size: 16px; color: #333; line-height: 1.6; }
                            .button { display: inline-block; margin-top: 20px; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 8px; font-weight: bold; transition: all 0.3s; }
                            .button:hover { background: #5568d3; transform: translateY(-2px); }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <h1>⚠️ Please Join the Server First</h1>
                            <p>You need to be a member of the Discord server before verifying.</p>
                            <p>Please join the server and then try verifying again.</p>
                            <a href="https://discord.gg/YOUR_INVITE" class="button">Join Server</a>
                        </div>
                    </body>
                    </html>
                `);
            }

            // Add verified role
            if (CONFIG.VERIFIED_ROLE_ID) {
                await member.roles.add(CONFIG.VERIFIED_ROLE_ID);
            }

            // Update nickname
            const newNickname = robloxUsername.substring(0, 32); // Discord 32 char limit
            await member.setNickname(newNickname).catch(() => {
                console.log('Could not update nickname (missing permissions or user is owner)');
            });

            // Sync group roles
            if (groupRank !== null) {
                await syncGroupRoles(member, groupRank);
            }

            // Send success DM with redirect to Discord
            try {
                await member.send({
                    embeds: [{
                        title: '✅ Verification Successful!',
                        description: `Your Discord account has been linked to **${robloxUsername}**\n\nYou can now close the verification tab and return to Discord.`,
                        fields: [
                            { name: 'Roblox Username', value: robloxUsername, inline: true },
                            { name: 'Roblox ID', value: robloxId, inline: true },
                            ...(groupRank !== null ? [
                                { name: 'Group Rank', value: `${groupRoleName} (${groupRank})`, inline: true }
                            ] : [])
                        ],
                        color: 0x00ff00,
                        timestamp: new Date(),
                        footer: {
                            text: 'Mokaí Verification System'
                        }
                    }]
                });
            } catch (e) {
                console.log('Could not DM user');
            }

            // Redirect back to Discord
            res.redirect(`discord://-/channels/${session.guildId}`);

        } catch (error) {
            console.error('Error updating Discord user:', error);
            res.status(500).send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Verification Error</title>
                    <style>
                        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #2c2f33; color: #fff; }
                        .container { text-align: center; background: #23272a; padding: 40px; border-radius: 10px; }
                        h1 { color: #ff4444; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>❌ Verification Error</h1>
                        <p>There was an error updating your Discord account.</p>
                        <p>Please contact an administrator for assistance.</p>
                    </div>
                </body>
                </html>
            `);
        }

    } catch (error) {
        console.error('Roblox OAuth error:', error.response?.data || error);
        res.status(500).send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Verification Failed</title>
                <style>
                    body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #2c2f33; color: #fff; }
                    .container { text-align: center; background: #23272a; padding: 40px; border-radius: 10px; }
                    h1 { color: #ff4444; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>❌ Verification Failed</h1>
                    <p>There was an error during Roblox verification.</p>
                    <p>Please try again or contact an administrator.</p>
                </div>
            </body>
            </html>
        `);
    }
});

// ===== HELPER FUNCTIONS =====
async function syncGroupRoles(member, groupRank) {
    // Remove old rank roles
    const rolesToRemove = [];
    for (const [rank, roleId] of Object.entries(CONFIG.ROLE_MAPPINGS)) {
        if (member.roles.cache.has(roleId) && rank !== groupRank.toString()) {
            rolesToRemove.push(roleId);
        }
    }

    if (rolesToRemove.length > 0) {
        await member.roles.remove(rolesToRemove);
    }

    // Add new rank role
    const newRoleId = CONFIG.ROLE_MAPPINGS[groupRank.toString()];
    if (newRoleId && !member.roles.cache.has(newRoleId)) {
        await member.roles.add(newRoleId);
    }
}

// ===== DISCORD COMMANDS =====
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'verify_roblox') {
        const verifyUrl = `${DOMAIN}/start-verify?guild=${interaction.guildId}`;
        
        await interaction.reply({
            embeds: [{
                title: '🔗 Verify Your Roblox Account',
                description: `Click the button below to link your Roblox account to Discord.\n\n**Verification Steps:**\n1️⃣ Authorize with Discord\n2️⃣ Authorize with Roblox\n3️⃣ Get verified instantly!\n\n**What happens:**\n✅ Your nickname will be set to your Roblox username\n✅ You'll receive roles based on your group rank\n✅ You'll get the verified role\n✅ Full server access`,
                color: 0x5865f2,
                footer: {
                    text: 'The process takes less than 30 seconds!'
                }
            }],
            components: [{
                type: 1,
                components: [{
                    type: 2,
                    style: ButtonStyle.Link,
                    label: 'Start Verification',
                    url: verifyUrl,
                    emoji: { name: '🚀' }
                }]
            }],
            ephemeral: true
        });
    }
});

// Post verification message
async function postVerificationMessage() {
    try {
        const channel = await client.channels.fetch(CONFIG.VERIFY_CHANNEL_ID);
        
        // Clear old messages
        const messages = await channel.messages.fetch({ limit: 10 });
        const botMessages = messages.filter(m => m.author.id === client.user.id);
        if (botMessages.size > 0) {
            await channel.bulkDelete(botMessages).catch(() => {});
        }
        
        await channel.send({
            embeds: [{
                title: '🔗 Roblox Verification System',
                description: `Welcome to **Mokaí**! To access the full server, you need to verify your Roblox account.\n\n**Why verify?**\n✅ Unlock all server channels\n✅ Get roles based on your group rank\n✅ Display your Roblox username\n✅ Become a verified member\n\n**How it works:**\nClick the button below and follow the simple 2-step process. You'll authorize with Discord first, then with Roblox. The whole process takes less than 30 seconds!`,
                color: 0x5865f2,
                thumbnail: {
                    url: 'https://cdn.discordapp.com/attachments/1411928640920490044/1435796544036147220/typo_initial_1.png'
                },
                footer: {
                    text: 'Your data is secure and only used for verification purposes'
                }
            }],
            components: [{
                type: 1,
                components: [{
                    type: 2,
                    style: ButtonStyle.Success,
                    label: 'Verify with Roblox',
                    custom_id: 'verify_roblox',
                    emoji: { name: '✅' }
                }]
            }]
        });

        console.log('✅ Verification message posted!');
    } catch (error) {
        console.error('❌ Error posting verification message:', error);
    }
}

// Command to manually sync roles
client.on('messageCreate', async message => {
    if (message.content === '?syncuser' && message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        const userId = message.mentions.users.first()?.id || message.author.id;
        const verifiedData = verifiedUsers.get(userId);

        if (!verifiedData) {
            return message.reply('❌ User is not verified.');
        }

        try {
            const member = await message.guild.members.fetch(userId);
            
            if (verifiedData.groupRank !== null) {
                await syncGroupRoles(member, verifiedData.groupRank);
                message.reply(`✅ Roles synced for ${verifiedData.robloxUsername}`);
            } else {
                message.reply('❌ User is not in the group.');
            }
        } catch (error) {
            console.error('Error syncing roles:', error);
            message.reply('❌ Error syncing roles.');
        }
    }

    // Post verification message
    if (message.content === '?postverify' && message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        await postVerificationMessage();
    }

    // Check verification status
    if (message.content === '?checkverify' && message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        const userId = message.mentions.users.first()?.id || message.author.id;
        const verifiedData = verifiedUsers.get(userId);

        if (!verifiedData) {
            return message.reply('❌ User is not verified.');
        }

        message.reply({
            embeds: [{
                title: 'Verification Status',
                fields: [
                    { name: 'Roblox Username', value: verifiedData.robloxUsername, inline: true },
                    { name: 'Roblox ID', value: verifiedData.robloxId, inline: true },
                    { name: 'Group Rank', value: verifiedData.groupRank?.toString() || 'Not in group', inline: true },
                    { name: 'Verified At', value: new Date(verifiedData.verifiedAt).toLocaleString(), inline: false }
                ],
                color: 0x00ff00
            }]
        });
    }
});

// ===== STARTUP =====
app.listen(PORT, () => {
    console.log(`🌐 Web server running on port ${PORT}`);
    console.log(`🔗 Redirect URI: ${CONFIG.REDIRECT_URI}`);
    console.log(`🔗 Discord Callback: ${DOMAIN}/discord-callback`);
});

client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}!`);
    console.log(`📋 Start verification at: ${DOMAIN}/start-verify?guild={GUILD_ID}`);
});

client.login(process.env.TOKEN);